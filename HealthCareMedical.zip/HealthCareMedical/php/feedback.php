<?php
echo "before ";
require_once 'conn/DB_Functions.php';
$db = new DB_Functions();
echo $db;
// json response array
$response = array("error" => FALSE);

if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['comments'])) {
 echo "test";
    // receiving the post params
    $fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$comments = $_POST['comments'];
    // Inserting the feedback
    $feed = $db->feedback($email, $password);

    if ($feed != false) {
        // feed is found
        $response["error"] = FALSE;
        echo json_encode($response);
    } else {
        // feed not added
        $response["error"] = TRUE;
        $response["error_msg"] = "Feedback not submitted!";
        echo json_encode($response);
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters is missing!";
    echo json_encode($response);
}
?>
