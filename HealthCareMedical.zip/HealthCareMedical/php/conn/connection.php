<?php

class DB_Connect {
    private $conn;

    // Connecting to database
    public function connect() {
        require_once 'include/Config.php';
        
        // Connecting to mysql database
        $this->conn = new mysqli(sql103.ultimatefreehost.in, ltm_19691736, Sree1729, ltm_19691736_login);
        
        // return database handler
        return $this->conn;
    }
}

?>
