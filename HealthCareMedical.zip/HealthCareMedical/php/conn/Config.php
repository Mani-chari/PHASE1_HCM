<?php
/**
 * Database config variables
 */
define("DB_HOST", "sql103.ultimatefreehost.in");
define("DB_USER", "ltm_19691736");
define("DB_PASSWORD", "Sree1729");
define("DB_DATABASE", "ltm_19691736_login");
?>
