<?php include '/conn/connection.php';?>
<html>
<body>
<?php 
$exp_date = "2006-01-16"; 

      $todays_date = date("Y-m-d",strtotime('-7 days')); 
	  
	  echo $todays_date."<br>";

      $today = strtotime($todays_date); 	
	  
	  echo $today;
echo "<br>";
      $expiration_date = strtotime($exp_date); 
	 echo $expiration_date+"<br>";
	echo "<br>";
      if ($expiration_date > $today) 
         { 
           $valid = "yes"; 
         } 
      else 
         { 
           $valid = "no"; 
         }
		 echo "SELECT * FROM `product` WHERE EXP <= '".$expiration_date."' order by Name";
		 $dat = $conn->query("SELECT AlertDays FROM `general settings`");
		 $res = $dat->fetch();
		 echo $res['AlertDays'];
?>
</body>
</html>